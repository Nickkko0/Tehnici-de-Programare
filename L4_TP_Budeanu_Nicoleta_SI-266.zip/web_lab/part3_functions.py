# Laborator: funcții, metode și importuri pe web
# Student: NicoletaBudeanu
BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

import time

import requests


def fetch(url: str, timeout: int = TIMEOUT) -> requests.Response:
    """Descarcă url și returnează obiectul răspuns."""
    return requests.get(url, timeout=timeout)


def get_status(url: str) -> int:
    """Returnează codul de stare HTTP pentru adresa url."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code


def get_title(html: str) -> str:
    """Returnează textul dintre <title> și </title>, sau un șir gol dacă lipsește."""
    start = html.find("<title>")
    end = html.find("</title>")
    if start == -1 or end == -1:
        return ""
    return html[start + len("<title>"):end].strip()


def page_exists(url: str) -> bool:
    """Returnează True dacă url răspunde cu succes, altfel False (fără erori)."""
    try:
        return requests.get(url, timeout=TIMEOUT).ok
    except requests.RequestException:
        return False


def check_paths(base: str, paths: list) -> dict:
    """Returnează {cale: cod_de_stare} pentru fiecare cale din listă."""
    results = {}
    for i, path in enumerate(paths):
        results[path] = get_status(base + path)
        if i < len(paths) - 1:
            time.sleep(1)
    return results


def get_header(url: str, name: str, default: str = "lipsește") -> str:
    """Returnează valoarea antetului name de la url, sau default dacă lipsește."""
    return requests.get(url, timeout=TIMEOUT).headers.get(name, default)


SECURITY_HEADERS = [
    "Strict-Transport-Security",
    "Content-Security-Policy",
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
]


def security_headers(url: str) -> dict:
    """Returnează {antet: True/False} pentru cele 5 antete de securitate."""
    headers = requests.get(url, timeout=TIMEOUT).headers
    return {name: name in headers for name in SECURITY_HEADERS}


def score_headers(results: dict) -> str:
    """Primește dicționarul din security_headers și returnează scorul, ex. '3/5'."""
    return f"{sum(results.values())}/{len(results)}"


def fetch_robots(base: str):
    """Returnează textul /robots.txt de la base, sau None dacă lipsește."""
    try:
        response = requests.get(base + "/robots.txt", timeout=TIMEOUT)
    except requests.RequestException:
        return None
    return response.text if response.status_code == 200 else None


def disallowed_paths(robots_text) -> list:
    """Returnează lista valorilor 'Disallow:' din robots_text (goală pentru None)."""
    if robots_text is None:
        return []
    paths = []
    for line in robots_text.splitlines():
        line = line.strip()
        if line.lower().startswith("disallow:"):
            value = line.split(":", 1)[1].strip()
            if value:
                paths.append(value)
    return paths


def response_times(*urls: str) -> dict:
    """Returnează {url: secunde} cu timpul de răspuns pentru fiecare url."""
    times = {}
    for i, url in enumerate(urls):
        start = time.perf_counter()
        requests.get(url, timeout=TIMEOUT)
        times[url] = round(time.perf_counter() - start, 3)
        if i < len(urls) - 1:
            time.sleep(1)
    return times


def log(message: str, **details) -> None:
    """Afișează mesajul urmat de fiecare detaliu, separate prin ' | '."""
    parts = [message] + [f"{key}={value}" for key, value in details.items()]
    print(" | ".join(parts))


if __name__ == "__main__":
    print("fetch:", fetch(BASE_URL).status_code)
    time.sleep(1)

    for path in ["/", "/robots.txt", "/sitemap.xml"]:
        print("get_status", path, "->", get_status(BASE_URL + path))
        time.sleep(1)

    print("timeout implicit:", fetch(BASE_URL).status_code)
    time.sleep(1)
    print("timeout=3:", fetch(BASE_URL, timeout=3).status_code)
    time.sleep(1)

    print("get_title:", get_title(fetch(BASE_URL).text))
    time.sleep(1)

    help(get_title)

    try:
        get_status(123)
    except Exception as err:
        print("get_status(123):", type(err).__name__, "-", err)
        # Adnotările de tip nu opresc apelul: Python nu le verifică la rulare.
        # Eroarea vine din requests, nu din adnotări.

    print("page_exists:", page_exists(BASE_URL))
    print("page_exists:", page_exists("https://this-domain-does-not-exist.invalid"))
    time.sleep(1)

    print("check_paths:", check_paths(BASE_URL, ["/", "/robots.txt", "/sitemap.xml"]))
    time.sleep(1)

    print("Server:", get_header(BASE_URL, name="Server"))
    time.sleep(1)

    sec = security_headers(BASE_URL)
    print("security_headers:", sec)
    print("score_headers:", score_headers(sec))
    time.sleep(1)

    robots = fetch_robots(BASE_URL)
    print("disallowed_paths:", disallowed_paths(robots))
    print("disallowed_paths(None):", disallowed_paths(None))
    time.sleep(1)

    print("response_times:", response_times(BASE_URL, BASE_URL + "/robots.txt"))

    log("verificat", url=BASE_URL, status=200)
