# Laborator: funcții, metode și importuri pe web
# Student: NicoletaBudeanu
BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

import time

import requests

response = requests.get(BASE_URL, timeout=TIMEOUT)
print(response.status_code)  # atribut
print(response.ok)           # atribut
print(response.url)          # atribut
print(response.encoding)     # atribut
time.sleep(1)

response = requests.get(BASE_URL, timeout=TIMEOUT)
response.raise_for_status()
print("Pagina principală: OK")
time.sleep(1)

try:
    bad = requests.get(BASE_URL + "/this-page-does-not-exist", timeout=TIMEOUT)
    bad.raise_for_status()
except requests.HTTPError as err:
    print("Pagina nu a fost găsită, dar programul continuă.")
    print("Detalii:", err)
time.sleep(1)

response = requests.get(BASE_URL, timeout=TIMEOUT)
for name, value in response.headers.items():
    print(f"{name}: {value}")

print("Server:", response.headers.get("Server", "lipsește"))
print("Content-Type:", response.headers.get("Content-Type", "lipsește"))
print("content-type:", response.headers.get("content-type", "lipsește"))
# Se obține aceeași valoare: response.headers nu e un dict obișnuit, ci un
# CaseInsensitiveDict, care ignoră diferența dintre litere mari și mici.

count = response.text.lower().count("cyber")
print("Cuvântul 'cyber' apare de", count, "ori")
# Se pot înlănțui pentru că .lower() returnează un șir nou (str), iar orice str
# are metoda .count(): rezultatul unei metode devine obiectul următoarei.

html = response.text
start = html.find("<title>") + len("<title>")
end = html.find("</title>")
title = html[start:end].strip()
print("Titlu:", title)

lines = html.splitlines()
print("Număr de linii:", len(lines))
print("Lungimea celei mai lungi linii:", len(max(lines, key=len)))

if response.url.startswith("https://"):
    print("Conexiune securizată")
else:
    print("Conexiune nesecurizată")
time.sleep(1)

response = requests.get("http://cybercor.org", timeout=TIMEOUT)
for hop in response.history:
    print(hop.status_code, hop.url)
print("URL final:", response.url)
time.sleep(1)

head_resp = requests.head(BASE_URL, timeout=TIMEOUT)
time.sleep(1)
get_resp = requests.get(BASE_URL, timeout=TIMEOUT)
print("HEAD:", len(head_resp.content))
print("GET:", len(get_resp.content))
# HEAD cere doar antetele, serverul nu trimite corpul, deci content e gol (0 octeți).
# GET cere și corpul, adică tot codul HTML al paginii.
time.sleep(1)

if len(get_resp.cookies) == 0:
    print("Niciun cookie setat")
else:
    for cookie in get_resp.cookies:
        print(cookie.name, cookie.secure)

session = requests.Session()
session.headers.update({"User-Agent": "WebLab-NicoletaBudeanu"})
echo = session.get(ECHO_URL + "/headers", timeout=TIMEOUT)
print(echo.json())
print("User-Agent primit:", echo.json()["headers"]["User-Agent"])
