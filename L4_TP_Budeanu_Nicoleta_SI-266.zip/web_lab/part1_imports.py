# Laborator: funcții, metode și importuri pe web
# Student: NicoletaBudeanu
BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

import time

import requests
print("Versiune requests:", requests.__version__)

import urllib.request
# requests este o bibliotecă externă, care nu vine cu Python, deci se instalează cu pip.
# urllib face parte din biblioteca standard, instalată automat odată cu Python.

r = requests.get(BASE_URL, timeout=TIMEOUT)
print("Stil 1 ->", r.status_code)
time.sleep(1)

from requests import get
r = get(BASE_URL, timeout=TIMEOUT)
print("Stil 2 ->", r.status_code)
time.sleep(1)
# import requests: se vede mereu de unde vine funcția și nu apar conflicte de nume.
# from requests import get: cod mai scurt, fără prefix.

import requests as rq
r = rq.get(BASE_URL, timeout=TIMEOUT)
print("Alias rq ->", r.status_code)
time.sleep(1)
# Alias-ul ajută când e o convenție cunoscută (np, pd) sau numele e lung.
# Îl face mai greu de citit când e criptic (rq, x), pentru că trebuie ghicit ce înseamnă.

req = urllib.request.Request(BASE_URL, headers={"User-Agent": "WebLab-NicoletaBudeanu"})
with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
    print("urllib status:", resp.status)
    body = resp.read().decode("utf-8")
    print(body[:200])
time.sleep(1)

print(dir(requests))
# get -> funcție
# Session -> clasă
# exceptions -> modul

help(requests.get)
r = requests.get(BASE_URL, timeout=TIMEOUT)
print("Cu timeout ->", r.status_code)
time.sleep(1)

start = time.perf_counter()
r = requests.get(BASE_URL, timeout=TIMEOUT)
end = time.perf_counter()
print(f"perf_counter: {end - start:.3f} s")
print(f"response.elapsed: {r.elapsed.total_seconds():.3f} s")

try:
    import bs4
    print("bs4 este instalat, versiunea", bs4.__version__)
except ImportError:
    print("Instalați modulul cu: pip install beautifulsoup4")
