# Laborator: funcții, metode și importuri pe web
# Student: NicoletaBudeanu
BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

import hashlib
import json
import re
import socket
import ssl
import time
from html.parser import HTMLParser
from urllib.parse import urljoin, urlparse

import requests


def parse_demo() -> None:
    """Afișează componentele unui URL cu urlparse."""
    parts = urlparse("https://cybercor.org/path?x=1#top")
    print("scheme  :", parts.scheme)
    print("netloc  :", parts.netloc)
    print("path    :", parts.path)
    print("query   :", parts.query)
    print("fragment:", parts.fragment)


def join_demo() -> None:
    """Transformă legături relative în URL-uri complete cu urljoin."""
    for link in ["/about", "contact.html", "../index.html"]:
        print(f"{link:15} -> {urljoin(BASE_URL, link)}")


def extract_links(html: str) -> list:
    """Returnează legăturile href din html, fără duplicate."""
    links = re.findall(r'href="([^"]+)"', html)
    return list(dict.fromkeys(links))


def split_links(links: list, domain: str) -> tuple:
    """Împarte legăturile în (interne, externe) față de domain."""
    base = "https://" + domain
    internal, external = [], []
    for link in links:
        full = urljoin(base, link)
        parsed = urlparse(full)
        if parsed.scheme not in ("http", "https"):
            continue
        if parsed.netloc == domain:
            internal.append(full)
        else:
            external.append(full)
    return internal, external


class ImageFinder(HTMLParser):
    """Colectează atributul src al fiecărui tag <img> în lista self.images."""

    def __init__(self):
        super().__init__()
        self.images = []

    def handle_starttag(self, tag, attrs):
        """Apelată automat de parser la fiecare tag de deschidere."""
        if tag == "img":
            src = dict(attrs).get("src")
            if src:
                self.images.append(src)


test_html = """
<html><body>
  <img src="/logo.png" alt="Logo">
  <IMG SRC="poza.jpg">
  <img alt="imagine fără src">
  <img src="https://cdn.example.com/banner.webp" />
  <a href="/despre">Aceasta nu este o imagine</a>
</body></html>
"""


def test_image_finder() -> None:
    """Testează ImageFinder pe un HTML cunoscut, apoi pe site-ul real."""
    finder = ImageFinder()
    finder.feed(test_html)
    print(finder.images)
    assert finder.images == [
        "/logo.png",                              # imagine obișnuită
        "poza.jpg",                               # tag scris cu majuscule
        "https://cdn.example.com/banner.webp",    # tag care se închide singur
    ], "Parserul nu a găsit exact imaginile așteptate"
    print("Testul a trecut!")

    response = requests.get(BASE_URL, timeout=TIMEOUT)
    finder = ImageFinder()
    finder.feed(response.text)
    print(len(finder.images), "imagini găsite")
    for src in finder.images:
        print(src)
    print("Număr <img în sursă:", response.text.lower().count("<img"))


def page_fingerprint(url: str) -> str:
    """Returnează amprenta SHA-256 (hex) a conținutului paginii de la url."""
    response = requests.get(url, timeout=TIMEOUT)
    return hashlib.sha256(response.content).hexdigest()


def save_headers_json(url: str, filename: str = "headers.json") -> None:
    """Salvează antetele de la url în JSON, apoi le reîncarcă și afișează unul."""
    response = requests.get(url, timeout=TIMEOUT)
    with open(filename, "w", encoding="utf-8") as file:
        json.dump(dict(response.headers), file, indent=2)
    with open(filename, encoding="utf-8") as file:
        loaded = json.load(file)
    print("Content-Type din fișier:", loaded.get("Content-Type", "lipsește"))


def resolve(hostname: str) -> str:
    """Returnează adresa IP (IPv4) a lui hostname."""
    return socket.gethostbyname(hostname)


def cert_days_left(hostname: str) -> int:
    """Returnează câte zile mai sunt până la expirarea certificatului lui hostname."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as secure:
            cert = secure.getpeercert()
    expires = ssl.cert_time_to_seconds(cert["notAfter"])
    return int((expires - time.time()) // 86400)


if __name__ == "__main__":
    parse_demo()
    join_demo()

    html = requests.get(BASE_URL, timeout=TIMEOUT).text
    links = extract_links(html)
    print("Legături unice:", len(links), links[:3])
    internal, external = split_links(links, urlparse(BASE_URL).netloc)
    print(len(internal), "interne,", len(external), "externe")
    time.sleep(1)

    test_image_finder()
    time.sleep(1)

    first = page_fingerprint(BASE_URL)
    time.sleep(1)
    second = page_fingerprint(BASE_URL)
    print("Amprentă:", first, "identice" if first == second else "diferite")
    # Ar fi diferite dacă pagina are conținut dinamic (dată/oră, token CSRF,
    # reclame, contor) sau dacă site-ul a fost modificat între cele două cereri.
    time.sleep(1)

    save_headers_json(BASE_URL)
    print("IP:", resolve("cybercor.org"))
    print("Certificat:", cert_days_left("cybercor.org"), "zile rămase")
