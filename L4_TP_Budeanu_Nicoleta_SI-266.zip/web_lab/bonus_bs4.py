# Laborator: funcții, metode și importuri pe web
# Student: NicoletaBudeanu
BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

import requests
from bs4 import BeautifulSoup


def get_title(html: str) -> str:
    """Returnează titlul paginii (sau șir gol), folosind BeautifulSoup."""
    soup = BeautifulSoup(html, "html.parser")
    return soup.title.get_text(strip=True) if soup.title else ""


def extract_links(html: str) -> list:
    """Returnează toate valorile href din tag-urile <a>, fără duplicate."""
    soup = BeautifulSoup(html, "html.parser")
    return list(dict.fromkeys(a["href"] for a in soup.find_all("a", href=True)))


if __name__ == "__main__":
    html = requests.get(BASE_URL, timeout=TIMEOUT).text
    print(get_title(html))
    print(extract_links(html))
    # Varianta cu find()/regex se strică la <title lang="ro">, <TITLE> sau href='...'.
    # BeautifulSoup parsează HTML-ul real, deci codul e mai scurt și mai sigur.
