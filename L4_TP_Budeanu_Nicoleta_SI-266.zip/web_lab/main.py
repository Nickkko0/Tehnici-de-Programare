# Laborator: funcții, metode și importuri pe web
# Student: NicoletaBudeanu
import argparse

import webtools
from webtools import DEFAULT_HEADERS, check_paths, get_title, security_headers, site_report, write_csv
# Dacă main.py ar avea o funcție proprie get_title, ea ar înlocui numele importat
# din webtools (se folosește ultima definiție), iar versiunea din webtools nu ar mai
# putea fi apelată prin numele simplu, doar prin webtools.get_title.


def main() -> None:
    """Citește URL-ul din linia de comandă și rulează toate verificările."""
    parser = argparse.ArgumentParser(description="Raport despre un site web")
    parser.add_argument("url", help="adresa site-ului, ex.: https://cybercor.org")
    args = parser.parse_args()
    url = args.url.rstrip("/")

    print("DEFAULT_HEADERS:", DEFAULT_HEADERS)
    print("Titlu:", webtools.get_title(webtools.fetch(url).text))
    print("Titlu:", get_title(webtools.fetch(url).text))
    print("Antete securitate:", security_headers(url))

    results = check_paths(url, ["/", "/robots.txt", "/sitemap.xml"])
    write_csv(results, "report.csv")
    print("Salvat în report.csv:", results)

    site_report(url, "report.json")


if __name__ == "__main__":
    main()
